JACOB PERSONAL TRAINER — APLICACIÓN ANDROID 1.2
================================================
Este ZIP es el PROYECTO FUENTE Android preparado para compilar; NO es todavía un archivo .apk.

FUNCIONES
- Calendario y jornadas (incluye los lunes 17:30 a 22:00 del cuadrante de noviembre 2026).
- Base de clientes, selección al añadir entrenamientos personales, entrenamientos grupales.
- Resumen económico, Excel XLSX, impresión/PDF A4, copias de seguridad JSON.
- Interfaz adaptada a móvil. Los datos se guardan localmente en el almacenamiento de ESTA aplicación.
- La lectura manuscrita con IA NO está conectada en este APK sin servidor, para evitar publicar contraseñas o claves.

IMPORTANTE: ANTES DE INSTALAR
En la versión actual del móvil (la web de Netlify), entra en Configuración > Descargar copia .JSON.
La versión APK tiene almacenamiento independiente del navegador Chrome. NO traspasa los datos sola.
Después de instalar el APK, ve a Configuración > RECUPERAR COPIA y selecciona el JSON guardado.
NO desinstales la PWA anterior hasta comprobar la migración completa.

MÉTODO A — COMPILAR CON ANDROID STUDIO EN PC (Windows/Mac/Linux)
1. Descomprime este ZIP.
2. Instala Android Studio desde https://developer.android.com/studio
3. Abre la carpeta Jacob_Trainer_Android_1_2 en Android Studio (Open).
4. Deja que se instale Android SDK 35 y Gradle 8.9 según solicite.
5. Menú Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Busca app/build/outputs/apk/debug/app-debug.apk
7. Envíate ese fichero APK a tu Xiaomi, ábrelo y acepta instalar desde esa fuente si confías en el origen.

MÉTODO B — COMPILACIÓN EN GITHUB ACTIONS (sin instalar Android Studio)
1. Crea un repositorio privado vacío de GitHub.
2. Sube TODOS los archivos y carpetas descomprimidos a la raíz del repositorio (incluido .github).
3. Abre Actions > Compilar Jacob Trainer APK > Run workflow (o espera al push a main).
4. Al finalizar con éxito, entra en el resultado > Artifacts > Jacob-Personal-Trainer-1.2-APK.
5. Descarga y descomprime el artifact ZIP; contiene app-debug.apk. Abre ese APK en el Xiaomi.
IMPORTANTE: No publiques claves de OpenAI ni copias de datos de clientes en ese repositorio.

NOTAS
- Es una build de desarrollo firmada con la clave de depuración que genere Gradle; para distribución futura y actualizaciones estables hay que firmar una versión de lanzamiento con una clave privada propia.
- La exportación Excel/JSON aparece en la carpeta Descargas/JacobTrainer del teléfono.
- Para PDF usa Resumen mensual > PDF / Imprimir > Guardar como PDF.
- La foto se puede elegir desde la galería; la lectura IA requiere un backend conectado.
- Las futuras versiones APK no actualizan automáticamente su contenido cuando cambias el sitio de Netlify.
- Funciona sin conexión para calendario, clientes y resumen económico.
