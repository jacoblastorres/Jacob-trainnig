const CACHE = 'jacob-trainer-pwa-v4';
const ROOT = new URL('./', self.registration.scope);
const STATIC_FILES = ['index.html','styles.css','app.js','xlsx-export.js','manifest.json','assets/icon-192.png','assets/icon-512.png'];
self.addEventListener('install', event => {event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(STATIC_FILES.map(file => new URL(file, ROOT)))));self.skipWaiting();});
self.addEventListener('activate', event => {event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith('jacob-trainer-') && key !== CACHE).map(key=>caches.delete(key)))));self.clients.claim();});
self.addEventListener('fetch', event=>{
 if (event.request.method!=='GET') return;
 const url=new URL(event.request.url);
 if (url.origin!==self.location.origin || url.pathname.includes('/api/')) return;
 event.respondWith(fetch(event.request).then(response=>{if(response.ok){const copy=response.clone();caches.open(CACHE).then(cache=>cache.put(event.request, copy));}return response;}).catch(()=>caches.match(event.request).then(hit=>hit||caches.match(new URL('index.html',ROOT)))));
});
