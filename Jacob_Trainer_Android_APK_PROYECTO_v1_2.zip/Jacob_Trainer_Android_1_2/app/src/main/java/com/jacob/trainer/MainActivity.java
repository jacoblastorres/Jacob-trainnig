package com.jacob.trainer;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.PrintManager;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.print.PrintAttributes;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.util.Base64;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int SELECT_FILE = 81;
    private static final String APP_ORIGIN = "https://appassets.androidplatform.net";
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(16, 26, 32));
        getWindow().setNavigationBarColor(Color.rgb(16, 26, 32));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(16, 26, 32));
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        webView.addJavascriptInterface(new AndroidInterface(), "JacobAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (!"https".equals(uri.getScheme()) || !"appassets.androidplatform.net".equals(uri.getHost())) {
                    return new WebResourceResponse("text/plain", "UTF-8", 403, "Blocked", null, new ByteArrayInputStream(new byte[0]));
                }
                String path = uri.getPath();
                if (path == null || path.equals("/")) path = "/index.html";
                if (path.contains("..") || path.contains("\\") || path.contains("%")) return new WebResourceResponse("text/plain", "UTF-8", 403, "Forbidden", null, new ByteArrayInputStream(new byte[0]));
                try {
                    String mime = mimeFor(path);
                    InputStream stream = getAssets().open(path.substring(1));
                    return new WebResourceResponse(mime, mime.startsWith("text/")||mime.contains("javascript") ? "UTF-8" : null, stream);
                } catch(IOException e) {
                    return new WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", null, new ByteArrayInputStream(new byte[0]));
                }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (APP_ORIGIN.equals(request.getUrl().getScheme()+"://"+request.getUrl().getHost())) return false;
                Intent intent = new Intent(Intent.ACTION_VIEW, request.getUrl());
                try { startActivity(intent); } catch (ActivityNotFoundException ignored) {}
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback=callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                try {startActivityForResult(Intent.createChooser(intent, "Seleccionar foto o copia JSON"), SELECT_FILE);}
                catch (ActivityNotFoundException e) {fileCallback.onReceiveValue(null);fileCallback=null;return false;}
                return true;
            }
        });
        webView.loadUrl(APP_ORIGIN + "/index.html");
    }

    private String mimeFor(String path) {
        String p=path.toLowerCase(Locale.ROOT);
        if(p.endsWith(".html"))return "text/html";
        if(p.endsWith(".css"))return "text/css";
        if(p.endsWith(".js")||p.endsWith(".mjs"))return "text/javascript";
        if(p.endsWith(".json"))return "application/json";
        if(p.endsWith(".svg"))return "image/svg+xml";
        if(p.endsWith(".png"))return "image/png";
        if(p.endsWith(".jpg")||p.endsWith(".jpeg"))return "image/jpeg";
        return "application/octet-stream";
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode==SELECT_FILE && fileCallback!=null) {
            Uri[] result = null;
            if (resultCode==RESULT_OK && data!=null && data.getData()!=null) result = new Uri[]{data.getData()};
            fileCallback.onReceiveValue(result);
            fileCallback=null;
        }
    }

    private class AndroidInterface {
        @JavascriptInterface public void saveFile(String filename, String mimeType, String base64) {
            new Thread(()->{
                try {
                    String cleanName=filename.replaceAll("[^a-zA-Z0-9À-ÿ_.\\-]", "_");
                    if(cleanName.length()>110) cleanName=cleanName.substring(cleanName.length()-110);
                    byte[] payload=Base64.getDecoder().decode(base64);
                    ContentValues values=new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, cleanName);
                    values.put(MediaStore.Downloads.MIME_TYPE, mimeType);
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS+"/JacobTrainer");
                    values.put(MediaStore.Downloads.IS_PENDING, 1);
                    Uri result=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
                    if(result==null)throw new IOException("No se pudo crear la descarga");
                    try(OutputStream stream=getContentResolver().openOutputStream(result)){
                        if(stream==null) throw new IOException("No se pudo escribir el archivo");
                        stream.write(payload);
                    }
                    ContentValues ready=new ContentValues(); ready.put(MediaStore.Downloads.IS_PENDING,0);
                    getContentResolver().update(result,ready,null,null);
                    mainHandler.post(()->Toast.makeText(MainActivity.this,"Archivo guardado en Descargas/JacobTrainer",Toast.LENGTH_LONG).show());
                } catch(Exception e) {
                    mainHandler.post(()->Toast.makeText(MainActivity.this,"Error al guardar: "+e.getMessage(),Toast.LENGTH_LONG).show());
                }
            }).start();
        }
        @JavascriptInterface public void printReport() {
            mainHandler.post(()->{
                PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);
                PrintAttributes pa=new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build();
                pm.print("Jacob Trainer - Resumen mensual",webView.createPrintDocumentAdapter("JacobTrainer"),pa);
            });
        }
    }

    @Override public void onBackPressed() {
        // Web app uses its own day drawer and menus. Avoid clearing its state on back.
        if (webView!=null && webView.canGoBack()) {webView.goBack();return;}
        super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if(webView!=null){webView.removeJavascriptInterface("JacobAndroid");webView.destroy();}
        super.onDestroy();
    }
}
